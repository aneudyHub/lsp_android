package com.system.lsp.utilidades;

/**
 * Created by Suarez on 14/06/2017.
 */

public class AppConfig {
    // Server user login url
    //public static String URL_LOGIN = "http://192.168.0.102/android_login_api/login.php";
    public static String URL_LOGIN = "http://192.168.10.49:8080/api.prestamos.com/";

    // Server user register url
    public static String URL_REGISTER = "http://192.168.10.49:8080/api.prestamos.com/";
}