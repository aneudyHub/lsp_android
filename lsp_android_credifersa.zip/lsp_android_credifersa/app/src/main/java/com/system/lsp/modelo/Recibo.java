package com.system.lsp.modelo;

/**
 * Created by aneudy on 1/11/2018.
 */

public class Recibo {
    int id;
    int cobrador_id;
    String fecha;
    String prestamos_id;

}
