package com.system.lsp.utilidades;

/**
 * Created by Suarez on 13/06/2017.
 */

public class URL {
     public final static String SERVER="http://api.hermanoshdez.com/";
    public final static String FOTO="http://www.hermanoshdez.com/storage/archivos/clientes/";
    //public final static String SERVER="http://143.137.83.145:8090/api.prestamos.com/v1/";
    //public final static String SERVER="http://192.168.0.5:8090/api.prestamos.com/v1/";
    public final static String HISTORIAL="cobrador/historial";
    public final static String LOGIN="usuarios/login";
    public final static String SYNC="sync";

}
